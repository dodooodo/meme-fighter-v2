Aggressive image optimization
=============================

Source: salad .zip

Applied:
- 10 images resized 1254x1254 -> 768x768 with Lanczos; aspect ratio preserved.
- PNG -> lossy WebP quality 72.
- Source alpha preserved on all RGBA files.
- No cropping; sprite-sheet order/grid preserved proportionally.
- __MACOSX metadata removed.
- No Godot project files were present, so no .tscn/.tres/.gd references required updating.

Image payload before: 18.80 MiB
Image payload after: 2.12 MiB
Image payload reduction: 88.71%

Per-file details: optimization_report.csv
